create definer = root@localhost trigger set_faculties_id
    before insert
    on faculties
    for each row
BEGIN
        IF NEW.id IS NULL OR NEW.id = '' THEN
            SET @max_id = (SELECT IFNULL(MAX(CAST(id AS UNSIGNED)), 0) + 1 FROM faculties);
            SET NEW.id = LPAD(@max_id , 3, '0');
            IF LENGTH(@max_id) < 3 THEN
                SET NEW.id = LPAD(@max_id , 3, '0');
            ELSE
                SET NEW.id = LPAD(@max_id , LENGTH(@max_id ), '0');
            END IF;
            ELSE
                SET NEW.id = NEW.id;
            END IF;
        END;

