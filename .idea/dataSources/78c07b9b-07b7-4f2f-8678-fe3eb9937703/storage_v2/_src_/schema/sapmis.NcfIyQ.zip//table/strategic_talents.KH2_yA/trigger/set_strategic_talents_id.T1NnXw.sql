create definer = root@localhost trigger set_strategic_talents_id
    before insert
    on strategic_talents
    for each row
BEGIN
        IF NEW.id IS NULL OR NEW.id = '' THEN
            SET @max_id = (SELECT IFNULL(MAX(CAST(id AS UNSIGNED)), 0) + 1 FROM strategic_talents);
            SET NEW.id = LPAD(@max_id , 1, '0');
            IF LENGTH(@max_id) < 1 THEN
                SET NEW.id = LPAD(@max_id , 1, '0');
            ELSE
                SET NEW.id = LPAD(@max_id , LENGTH(@max_id ), '0');
            END IF;
            ELSE
                SET NEW.id = NEW.id;
            END IF;
        END;

